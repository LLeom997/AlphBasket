
export const saveUserConfig = async (config: any) => {
    // No-op in demo mode
};

export const getUserConfig = async () => {
    // No-op in demo mode
    return null;
};
